<header class="app-header">
    <nav class="navbar navbar-expand-lg navbar-light">
        
        
    </nav>
</header><?php /**PATH E:\Programs\laragon\www\objectdetect-laravel\resources\views/layout/header.blade.php ENDPATH**/ ?>